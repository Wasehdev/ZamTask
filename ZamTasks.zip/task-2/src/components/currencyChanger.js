import React from "react";

const CurrencyChanger = () => {
  const handleRupee = e => {
    let dollars = e / 168;
    dollars = parseFloat(dollars).toFixed(4);
    document.getElementById("dollar").value = dollars;
  };
  const handleDollars = e => {
    let rupee = e * 168;
    rupee = parseFloat(rupee).toFixed(4);
    document.getElementById("rupee").value = rupee;
  };

  return (
    <div>
      <div>
        <label>In Rupees</label>
        <input
          id="rupee"
          onChange={e => handleRupee(e.target.value)}
          type="number"
        ></input>
      </div>
      <div>
        <label>In Dollars</label>
        <input
          id="dollar"
          type="number"
          onChange={e => handleDollars(e.target.value)}
        ></input>
      </div>
    </div>
  );
};

export default CurrencyChanger;
