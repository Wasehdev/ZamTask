import "./App.css";
import CurrencyChanger from "./components/currencyChanger";

function App() {
  return (
    <div className="App">
      <div>Currency Changer</div>
      <CurrencyChanger></CurrencyChanger>
    </div>
  );
}

export default App;
