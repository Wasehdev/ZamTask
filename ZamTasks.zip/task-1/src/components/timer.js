import React, { useState, useEffect } from "react";
import styled from "styled-components";

const Timer = () => {
  const [count, setCount] = useState(25);

  useEffect(() => {
    if (count == 20) {
      document.body.style.backgroundColor = "Black";
      document.body.style.color = "white";
    } else if (count == 10) {
      document.body.style.backgroundColor = "Yellow";
    } else if (count == 5) {
      document.body.style.backgroundColor = "Black";
    }

    const timer = count > 0 && setInterval(() => setCount(count - 1), 1000);
    console.log(timer);
    return () => clearInterval(timer);
  }, [count]);
  return (
    <div>
      <Counter>
        <span>{count}</span>
      </Counter>
    </div>
  );
};
const Counter = styled.div`
  text-align: center;
  font-size: 60px;
  margin-top: 20%;
  font-weight: 1000;
`;

export default Timer;
